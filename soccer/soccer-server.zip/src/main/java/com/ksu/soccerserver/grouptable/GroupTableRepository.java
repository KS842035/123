package com.ksu.soccerserver.grouptable;

import org.springframework.data.jpa.repository.JpaRepository;

public interface GroupTableRepository extends JpaRepository<GroupTable, Long> {

}
