package com.ksu.soccerserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoccerServerApplication {

    public static void main(String[] args) {
        SpringApplication.run(SoccerServerApplication.class, args);
    }

}
